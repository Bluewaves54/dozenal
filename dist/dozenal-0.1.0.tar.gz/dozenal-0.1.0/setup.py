from setuptools import setup, find_packages

setup(
    name='dozenal',
    version='0.1.0',
    description='A Python package for handling the Dozenal (base 12) system.',
    author='Your Name',
    packages=find_packages(),
    install_requires=[],
    python_requires='>=3.6',
)
